public enum Snek  {
    SNIKERS, TWIX, BROT, WURST
}
