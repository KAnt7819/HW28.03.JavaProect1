import java.util.Scanner;

public class Main {

    //Создайте перечисление для угощений в снек-автомате (3-4 позиции).
    //Пользователь вводит номер снека. Программа должна вывести название снека, который выдал автомат.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Geben Sie die Sneknummer ein: ");
        int snekNummer = scn.nextInt();
        if (snekNummer == 1){
            System.out.println(Snek.SNIKERS);
        }
        if (snekNummer == 2){
            System.out.println(Snek.TWIX);
        }
        if (snekNummer == 3){
            System.out.println(Snek.BROT);
        }
        if (snekNummer == 4){
            System.out.println(Snek.WURST);
        }

    }
}